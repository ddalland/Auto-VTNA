Auto-VTNA
=========
Python package for performing automatic VTNA. 
For more info and user guides see https://chemrxiv.org/engage/chemrxiv/article-details/65fddc2d66c1381729948bb2. 
More info will soon be provided, including tutorials in Jupyter Notebook and on Youtube. 